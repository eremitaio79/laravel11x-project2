# Laravel Studies
Este projeto foi criado no contexto do curso
Laravel Completo - Framework, ecossistema e Projetos Web (Udemy)
@João Ribeiro

# Instalação
Abrir o terminal e executar o seguinte comando:
composer update