<?php

use Illuminate\Support\Facades\Route;

Route::view('/','home');
