<?php if (isset($component)) { $__componentOriginala467e27a8a64a28aea549eeab6f9a9c7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala467e27a8a64a28aea549eeab6f9a9c7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.main-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <p class="text-center text-secondary mb-5">Projeto simples de Laravel 11 com o intuíto de ser usado para testar a colocação em PRODUÇÃO</p>

    <div class="d-flex gap-5 justify-content-center mb-5">

        <a href="<?php echo e(route('clients.all')); ?>" class="btn btn-secondary px-5">CLIENTES (MySQL)</a>
        <a href="<?php echo e(route('create.file')); ?>" class="btn btn-secondary px-5">CRIAR FICHEIRO</a>
        <a href="<?php echo e(route('list.files')); ?>" class="btn btn-secondary px-5">LISTAR FICHEIROS</a>
        <a href="<?php echo e(route('delete.files')); ?>" class="btn btn-secondary px-5">ELIMINAR TODOS OS FICHEIROS</a>

    </div>

    <?php if(session('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala467e27a8a64a28aea549eeab6f9a9c7)): ?>
<?php $attributes = $__attributesOriginala467e27a8a64a28aea549eeab6f9a9c7; ?>
<?php unset($__attributesOriginala467e27a8a64a28aea549eeab6f9a9c7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala467e27a8a64a28aea549eeab6f9a9c7)): ?>
<?php $component = $__componentOriginala467e27a8a64a28aea549eeab6f9a9c7; ?>
<?php unset($__componentOriginala467e27a8a64a28aea549eeab6f9a9c7); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\LARAVEL_UDEMY\laravel_project\resources\views/home.blade.php ENDPATH**/ ?>