<?php if (isset($component)) { $__componentOriginala467e27a8a64a28aea549eeab6f9a9c7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala467e27a8a64a28aea549eeab6f9a9c7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.main-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <p class="display-6">Lista de ficheiros</p>
    <hr>

    <?php if(empty($files)): ?>
        <p class="text-secondary">Não existem ficheiros</p>
    <?php else: ?>
        <ul>
            <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <?php echo e($file); ?>

                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

        <a href="<?php echo e(route('delete.files')); ?>" class="btn btn-danger">Eliminar todos os ficheiros</a>

    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala467e27a8a64a28aea549eeab6f9a9c7)): ?>
<?php $attributes = $__attributesOriginala467e27a8a64a28aea549eeab6f9a9c7; ?>
<?php unset($__attributesOriginala467e27a8a64a28aea549eeab6f9a9c7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala467e27a8a64a28aea549eeab6f9a9c7)): ?>
<?php $component = $__componentOriginala467e27a8a64a28aea549eeab6f9a9c7; ?>
<?php unset($__componentOriginala467e27a8a64a28aea549eeab6f9a9c7); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\LARAVEL_UDEMY\laravel_project\resources\views/clients/files.blade.php ENDPATH**/ ?>