<?php if (isset($component)) { $__componentOriginala467e27a8a64a28aea549eeab6f9a9c7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala467e27a8a64a28aea549eeab6f9a9c7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.main-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <table class="table table-bordered table-striped">

        <thead class="table-light">
            <tr>
                <th>Name</th>
                <th>Email</th>
            </tr>
        </thead>

        <tbody class="table-dark">
            <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($client->name); ?></td>
                    <td><?php echo e($client->email); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php echo e($clients->links()); ?>



 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala467e27a8a64a28aea549eeab6f9a9c7)): ?>
<?php $attributes = $__attributesOriginala467e27a8a64a28aea549eeab6f9a9c7; ?>
<?php unset($__attributesOriginala467e27a8a64a28aea549eeab6f9a9c7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala467e27a8a64a28aea549eeab6f9a9c7)): ?>
<?php $component = $__componentOriginala467e27a8a64a28aea549eeab6f9a9c7; ?>
<?php unset($__componentOriginala467e27a8a64a28aea549eeab6f9a9c7); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\LARAVEL_UDEMY\laravel_project\resources\views/clients/index.blade.php ENDPATH**/ ?>