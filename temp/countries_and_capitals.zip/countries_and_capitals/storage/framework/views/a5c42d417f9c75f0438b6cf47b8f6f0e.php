<div class="col-6 text-center">
    <a href="<?php echo e(route('answer', Crypt::encryptString($capital))); ?>" class="text-decoration-none">
        <p class="response-option"><?php echo e($capital); ?></p>
    </a>
</div><?php /**PATH C:\laragon\www\countries_and_capitals\resources\views/components/answer.blade.php ENDPATH**/ ?>