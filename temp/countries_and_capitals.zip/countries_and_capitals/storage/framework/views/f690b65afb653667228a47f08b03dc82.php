<?php if (isset($component)) { $__componentOriginal66d7cfd03cd343304d81fe1e21646540 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal66d7cfd03cd343304d81fe1e21646540 = $attributes; } ?>
<?php $component = App\View\Components\MainLayout::resolve(['pageTitle' => 'Countries & Capitals Quiz'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\MainLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="container">

        <?php if (isset($component)) { $__componentOriginale7ec0bd96f389b19f2ebc529a7e42426 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale7ec0bd96f389b19f2ebc529a7e42426 = $attributes; } ?>
<?php $component = App\View\Components\Question::resolve(['country' => $country,'currentQuestion' => $currentQuestion,'totalQuestions' => $totalQuestions] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('question'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Question::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale7ec0bd96f389b19f2ebc529a7e42426)): ?>
<?php $attributes = $__attributesOriginale7ec0bd96f389b19f2ebc529a7e42426; ?>
<?php unset($__attributesOriginale7ec0bd96f389b19f2ebc529a7e42426); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale7ec0bd96f389b19f2ebc529a7e42426)): ?>
<?php $component = $__componentOriginale7ec0bd96f389b19f2ebc529a7e42426; ?>
<?php unset($__componentOriginale7ec0bd96f389b19f2ebc529a7e42426); ?>
<?php endif; ?>

        <div class="row">

            <?php $__currentLoopData = $answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginal812d1c6e1d8da72c5ba3ac4b7d3d220a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal812d1c6e1d8da72c5ba3ac4b7d3d220a = $attributes; } ?>
<?php $component = App\View\Components\Answer::resolve(['capital' => $answer] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('answer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Answer::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal812d1c6e1d8da72c5ba3ac4b7d3d220a)): ?>
<?php $attributes = $__attributesOriginal812d1c6e1d8da72c5ba3ac4b7d3d220a; ?>
<?php unset($__attributesOriginal812d1c6e1d8da72c5ba3ac4b7d3d220a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal812d1c6e1d8da72c5ba3ac4b7d3d220a)): ?>
<?php $component = $__componentOriginal812d1c6e1d8da72c5ba3ac4b7d3d220a; ?>
<?php unset($__componentOriginal812d1c6e1d8da72c5ba3ac4b7d3d220a); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        
    </div>

    <!-- cancel game -->
    <div class="text-center mt-5">
        <a href="<?php echo e(route('start_game')); ?>" class="btn btn-outline-danger mt-3 px-5">CANCELAR JOGO</a>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $attributes = $__attributesOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $component = $__componentOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__componentOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\countries_and_capitals\resources\views/game.blade.php ENDPATH**/ ?>