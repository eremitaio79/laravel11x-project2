<div class="border border-primary rounded-5 p-3 text-center fs-3 mb-3">
    Pergunta: <span class="text-info fw-bolder"><?php echo e($currentQuestion + 1); ?> / <?php echo e($totalQuestions); ?></span>
</div>

<div class="text-center fs-3 mb-3">
    Qual é a capital de <?php echo e($country); ?> ?
</div><?php /**PATH C:\laragon\www\countries_and_capitals\resources\views/components/question.blade.php ENDPATH**/ ?>