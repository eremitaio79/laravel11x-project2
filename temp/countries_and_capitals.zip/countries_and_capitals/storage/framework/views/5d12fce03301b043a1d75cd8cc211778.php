<footer class="text-center mt-5 text-secondary">
    Countries & Capitals Quiz &copy; <?php echo date('Y'); ?>
</footer><?php /**PATH C:\laragon\www\countries_and_capitals\resources\views/components/footer.blade.php ENDPATH**/ ?>