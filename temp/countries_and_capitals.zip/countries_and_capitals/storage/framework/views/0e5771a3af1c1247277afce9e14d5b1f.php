<div class="container mt-5">
    <div class="row">
        <div class="col-12 text-center">
            <img src="<?php echo e(asset('assets/images/logo.jpg')); ?>" alt="logo" class="img-fluid">
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\countries_and_capitals\resources\views/components/logo.blade.php ENDPATH**/ ?>