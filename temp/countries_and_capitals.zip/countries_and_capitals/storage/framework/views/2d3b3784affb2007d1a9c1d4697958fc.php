<?php if (isset($component)) { $__componentOriginal66d7cfd03cd343304d81fe1e21646540 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal66d7cfd03cd343304d81fe1e21646540 = $attributes; } ?>
<?php $component = App\View\Components\MainLayout::resolve(['pageTitle' => 'Countries & Capitals Quiz'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\MainLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="container">

        <?php if (isset($component)) { $__componentOriginale7ec0bd96f389b19f2ebc529a7e42426 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale7ec0bd96f389b19f2ebc529a7e42426 = $attributes; } ?>
<?php $component = App\View\Components\Question::resolve(['country' => $country,'currentQuestion' => $currentQuestion,'totalQuestions' => $totalQuestions] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('question'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Question::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale7ec0bd96f389b19f2ebc529a7e42426)): ?>
<?php $attributes = $__attributesOriginale7ec0bd96f389b19f2ebc529a7e42426; ?>
<?php unset($__attributesOriginale7ec0bd96f389b19f2ebc529a7e42426); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale7ec0bd96f389b19f2ebc529a7e42426)): ?>
<?php $component = $__componentOriginale7ec0bd96f389b19f2ebc529a7e42426; ?>
<?php unset($__componentOriginale7ec0bd96f389b19f2ebc529a7e42426); ?>
<?php endif; ?>

        <div class="text-center fs-3 mb-3">
            Resposta correta: <span class="text-info"><?php echo e($correct_answer); ?></span>
        </div>

        <div class="text-center fs-3 mb-3">
            A sua resposta: <span class="[conditional]"><?php echo e($choice_answer); ?></span>
        </div>
        
    </div>

    <!-- cancel game -->
    <div class="text-center mt-5">
        <a href="<?php echo e(route('next_question')); ?>" class="btn btn-primary mt-3 px-5">AVANÇAR</a>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $attributes = $__attributesOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $component = $__componentOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__componentOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\countries_and_capitals\resources\views/answer_result.blade.php ENDPATH**/ ?>